const express = require('express');

const app = express();

// listen for requests

app.listen(2000);

app.use(express.static('public'));

app.get('/', (req, res) => {

    res.sendFile('./www/index.html', { root: __dirname });

});

app.get('/aids', (req, res) => {

    res.sendFile('./www/aids.html', { root: __dirname });

});

app.get('/aids/treatment', (req, res) => {

    res.sendFile('./www/aids-treatment.html', { root: __dirname });

});

app.get('/covid', (req, res) => {

    res.sendFile('./www/covid.html', { root: __dirname });

});

app.get('/covid/treatment', (req, res) => {

    res.sendFile('./www/covid-treatment.html', { root: __dirname });

});

app.get('/cancer', (req, res) => {

    res.sendFile('./www/cancer.html', { root: __dirname });

});

app.get('/cancer/treatment', (req, res) => {

    res.sendFile('./www/cancer-treatment.html', { root: __dirname });

});

app.get('/cirrhosis', (req, res) => {

    res.sendFile('./www/cirrhosis.html', { root: __dirname });

});

app.get('/cirrhosis/treatment', (req, res) => {

    res.sendFile('./www/cirrhosis-treatment.html', { root: __dirname });

});

app.get('/covid', (req, res) => {

    res.sendFile('./www/covid.html', { root: __dirname });

});

app.get('/covid/treatment', (req, res) => {

    res.sendFile('./www/covid-treatment.html', { root: __dirname });

});

app.get('/diabetes', (req, res) => {

    res.sendFile('./www/diabetes.html', { root: __dirname });

});

app.get('/diabetes/treatment', (req, res) => {

    res.sendFile('./www/diabetes-treatment.html', { root: __dirname });

});

app.get('/less-than-3', (req, res) => {

    res.sendFile('./www/less-than-3.html', { root: __dirname });

});

app.get('/less-than-3/treatment', (req, res) => {

    res.sendFile('./www/less-than-3-treatment.html', { root: __dirname });

});

app.get('/lupus', (req, res) => {

    res.sendFile('./www/lupus.html', { root: __dirname });

});

app.get('/lupus/treatment', (req, res) => {

    res.sendFile('./www/lupus-treatment.html', { root: __dirname });

});

app.get('/lyme-disease', (req, res) => {

    res.sendFile('./www/lyme-disease.html', { root: __dirname });

});

app.get('/lyme-disease/treatment', (req, res) => {

    res.sendFile('./www/lyme-disease-treatment.html', { root: __dirname });

});

app.get('/malaria', (req, res) => {

    res.sendFile('./www/malaria.html', { root: __dirname });

});

app.get('/malaria/treatment', (req, res) => {

    res.sendFile('./www/malaria-treatment.html', { root: __dirname });

});

app.get('/meningitis', (req, res) => {

    res.sendFile('./www/meningitis.html', { root: __dirname });

});

app.get('/meningitis/treatment', (req, res) => {

    res.sendFile('./www/meningitis_treatment.html', { root: __dirname });

});

app.get('/mumps', (req, res) => {

    res.sendFile('./www/mumps.html', { root: __dirname });

});

app.get('/mumps/treatment', (req, res) => {

    res.sendFile('./www/mumps-treatment.html', { root: __dirname });

});

app.get('/pneumonia', (req, res) => {

    res.sendFile('./www/pneumonia.html', { root: __dirname });

});

app.get('/pneumonia/treatment', (req, res) => {

    res.sendFile('./www/pneumonia-treatment.html', { root: __dirname });

});

app.get('/tuberculosis', (req, res) => {
    res.sendFile('./www/tuberculosis.html', { root: __dirname });
});

app.get('/tuberculosis/treatment', (req, res) => {
    res.sendFile('./www/tuberculosis-treatment.html', {root: __dirname });
})