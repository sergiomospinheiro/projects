var genre; // boolean true = male, false = female
var age; // integer
var symptoms = [fever = false, cough = false, lostTasteSmell = false, chestPain = false, soreThroat = false, muscleAche = false, rash = false, nightSweat = false, chills = false, blurryVision = false, fatigue = false, uncontrolledPee = false, headache = false, lostAppetite = false, tenderBalls = false, coughBlood = false, diarrhea = false, easyInjuries = false];
var symptomsAmmount = 0;
var symptomsCounter = 0;

function feverDream() {
    if (fever == false) {
        fever = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        fever = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function coughalot() {
    if (cough == false) {
        cough = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        cough = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function cantTasteSmell() {
    if (lostTasteSmell == false) {
        lostTasteSmell = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        lostTasteSmell = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function chestHurts() {
    if (chestPain == false) {
        chestPain = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        chestPain = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function throatHurts() {
    if (soreThroat == false) {
        soreThroat = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        soreThroat = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function muscleHurts() {
    if (muscleAche == false) {
        muscleAche = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        muscleAche = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function redSkin() {
    if (rash == false) {
        rash = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        rash = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function sweaty() {
    if (nightSweat == false) {
        nightSweat = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        nightSweat = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function chillsBruh() {
    if (chills == false) {
        chills = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        chills = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function johnCena() {
    if (blurryVision == false) {
        blurryVision = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        blurryVision = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function fatigued() {
    if (fatigue == false) {
        fatigue = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        fatigue = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function peeMyPants() {
    if (uncontrolledPee == false) {
        uncontrolledPee = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        uncontrolledPee = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function headHurts() {
    if (headache == false) {
        headache = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        headache = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function notHungry() {
    if (lostAppetite == false) {
        lostAppetite = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        lostAppetite = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function balls() {
    if (tenderBalls == false) {
        tenderBalls = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        tenderBalls = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function bloody() {
    if (coughBlood == false) {
        coughBlood = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        coughBlood = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function poopyPants() {
    if (diarrhea == false) {
        diarrhea = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        diarrhea = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

function bleedAlot() {
    if (easyInjuries == false) {
        easyInjuries = true;
        symptomsAmmount = symptomsAmmount + 1
    } else {
        easyInjuries = false;
        symptomsAmmount = symptomsAmmount - 1
    }
}

//REDIRECTS
function aidsTreatment() {
    window.location.href = "http://localhost:3000/aids/treatment"
}

function cancerTreatment() {
    window.location.href = "http://localhost:3000/cancer/treatment"
}

function cirrhosisTreatment() {
    window.location.href = "http://localhost:3000/cirrhosis/treatment"
}

function covidTreatment() {
    window.location.href = "http://localhost:3000/covid/treatment"
}

function diabetesTreatment() {
    window.location.href = "http://localhost:3000/diabetes/treatment"
}

function lymeTreatment() {
    window.location.href = "http://localhost:3000/lyme-disease/treatment"
}

function malariaTreatment() {
    window.location.href = "http://localhost:3000/malaria/treatment"
}

function meningitisTreatment() {
    window.location.href = "http://localhost:3000/meningitis/treatment"
}

function mumpsTreatment() {
    window.location.href = "http://localhost:3000/mumps/treatment"
}

function pneumoniaTreatment() {
    window.location.href = "http://localhost:3000/pneumonia/treatment"
}

function tuberculosisTreatment() {
    window.location.href = "http://localhost:3000/tuberculosis/treatment"
}

function lupusTreatment() {
    window.location.href = "http://localhost:3000/lupus/treatment"
}

function pussyTreatment() {
    window.location.href = "http://localhost:3000/less-than-3/treatment"
}

function home() {
    window.location.href = "http://localhost:3000/"
}

//MALE
function whatdisease() {
    if (rash == true && nightSweat == true && chills == true) {
        window.location.href = "http://localhost:3000/aids";
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fatigue == true && easyInjuries == true && lostAppetite == true) {
        window.location.href = "http://localhost:3000/cirrhosis";
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fever == true && cough == true && lostTasteSmell == true) {
        window.location.href = "http://localhost:3000/covid"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (blurryVision == true && fatigue == true && uncontrolledPee == true) {
        window.location.href = "http://localhost:3000/diabetes"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fever == true && fatigue == true && headache == true) {
        window.location.href = "http://localhost:3000/lyme-disease"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (diarrhea == true && fatigue == true && headache == true) {
        window.location.href = "http://localhost:3000/malaria"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fever == true && headache == true && muscleAche == true) {
        window.location.href = "http://localhost:3000/meningitis"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fever == true && lostAppetite == true && tenderBalls == true) {
        window.location.href = "http://localhost:3000/mumps"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (chestPain == true && soreThroat == true && muscleAche == true) {
        window.location.href = "http://localhost:3000/pneumonia"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (fever == true && fatigue == true && coughBlood == true) {
        window.location.href = "http://localhost:3000/tuberculosis"
    } else {
        symptomsCounter = symptomsCounter + 1;
    }
    if (symptomsAmmount > 3) {
        window.location.href = "http://localhost:3000/cancer"
    }
    if (symptomsCounter == 10 && symptomsAmmount == 3) {
        window.location.href = "http://localhost:3000/lupus"
    }

    if (symptomsAmmount < 3) {
        window.location.href = "http://localhost:3000/less-than-3"
    }

}
